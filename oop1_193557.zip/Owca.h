#pragma once
#include "Zwierze.h"
class Owca :
    public Zwierze
{
    public:
	Owca(int x, int y);
    Owca* dziecko();
};

